import java.util.*;

/**
 * Missions 3 and 4. Find a word in a long text.
 */
public class Marker {

    /** Mission 3a. Prefix function: pi[i] = length of the longest border of p[0..i]. */
    public static int[] prefixFunction(String p) {
        int m = p.length();
        int[] pi = new int[m];
        int len = 0;                                       // length of the current border
        for (int i = 1; i < m; i++) {
            while (len > 0 && p.charAt(i) != p.charAt(len)) {
                len = pi[len - 1];                         // fall back to a shorter border
            }
            if (p.charAt(i) == p.charAt(len)) len++;       // the border grows by one letter
            pi[i] = len;
        }
        return pi;
    }

    /** Mission 3b. KMP: all start positions of p in text (overlaps count). The text pointer never goes back. */
    public static int[] findAll(String text, String p) {
        int n = text.length(), m = p.length();
        if (m == 0 || m > n) return new int[0];
        int[] pi = prefixFunction(p);
        int[] found = new int[n];
        int count = 0;
        int k = 0;                                         // how many letters of p are matched now
        for (int i = 0; i < n; i++) {
            while (k > 0 && text.charAt(i) != p.charAt(k)) {
                k = pi[k - 1];                             // mismatch: fall back, do not move i
            }
            if (text.charAt(i) == p.charAt(k)) k++;
            if (k == m) {                                  // full match ends at i
                found[count++] = i - m + 1;
                k = pi[m - 1];                             // the next match may overlap this one
            }
        }
        return Arrays.copyOf(found, count);
    }

    private static final long BASE = 131;
    private static final long MOD = 1_000_000_007L;

    /**
     * Mission 4. Rabin-Karp with a rolling hash. Counts the positions i of a such that the k letters a[i..i+k-1]
     * occur somewhere in b. Equal hashes are always checked letter by letter.
     */
    public static int sharedWords(String a, String b, int k) {
        int n = a.length(), m = b.length();
        if (k <= 0 || n < k || m < k) return 0;

        long top = 1;                                      // BASE^(k-1) mod MOD
        for (int i = 1; i < k; i++) top = top * BASE % MOD;

        // all windows of b: hash -> start positions
        Map<Long, List<Integer>> windows = new HashMap<>();
        long h = 0;
        for (int i = 0; i < k; i++) h = (h * BASE + b.charAt(i)) % MOD;
        windows.computeIfAbsent(h, x -> new ArrayList<>()).add(0);
        for (int i = 1; i + k <= m; i++) {
            h = ((h - b.charAt(i - 1) * top % MOD + MOD) % MOD * BASE + b.charAt(i + k - 1)) % MOD;   // roll the window
            windows.computeIfAbsent(h, x -> new ArrayList<>()).add(i);
        }

        int count = 0;
        h = 0;
        for (int i = 0; i < k; i++) h = (h * BASE + a.charAt(i)) % MOD;
        for (int i = 0; ; i++) {
            List<Integer> candidates = windows.get(h);
            if (candidates != null) {
                for (int pos : candidates) {
                    if (sameLetters(a, i, b, pos, k)) { count++; break; }   // hash equal: compare the letters
                }
            }
            if (i + k >= n) break;
            h = ((h - a.charAt(i) * top % MOD + MOD) % MOD * BASE + a.charAt(i + k)) % MOD;
        }
        return count;
    }

    private static boolean sameLetters(String a, int i, String b, int j, int k) {
        for (int t = 0; t < k; t++) if (a.charAt(i + t) != b.charAt(j + t)) return false;
        return true;
    }
}
