# Assignment 4. Patient Zero

Student ID: 252125

This file is the report. How to start: `START_HERE.md`. The task: `docs/Assignment4.pdf`.

## Program output

The 9 lines my program prints on my data (`java -cp out Main`):

    Mutations: 76
    Shared core: 1164
    Marker hits: 7
    First hit: 3069
    Border length: 3
    Shared words: 556
    Tests needed: 38
    Cheapest testing: 151
    Longest chain: 25

My outbreak report (a screenshot of `output/outbreak.html`, all 9 lines have a tick):

![outbreak](output/outbreak.png)

`java tools/Check.java` shows that the three examples (tiny, small, dense) give the right output.

## Questions

**Mission 1.** The cell d[i][j] is the smallest number of changes (replace, insert, delete a letter) that turn the first i letters of A into the first j letters of B. If the last two letters are equal, d[i][j] = d[i-1][j-1]. Otherwise d[i][j] = 1 + the smallest of d[i-1][j-1] (replace), d[i-1][j] (delete a letter of A) and d[i][j-1] (insert a letter of B). The first row is 0, 1, 2, ... (insert j letters into an empty word) and the first column is the same (delete i letters). The answer is the bottom right cell.

**Mission 2.** A common subsequence keeps the order of the letters but the letters do not have to stand next to each other, while a common substring must be one unbroken block. The table is the same as in Mission 1 but with another rule: if the letters are equal, d[i][j] = d[i-1][j-1] + 1, otherwise the bigger of d[i-1][j] and d[i][j-1]. My Shared core (1164) is bigger than the number of letters that are equal at the same place, because after an inserted or a deleted letter the rest of the strain is shifted, and the common letters stand at different places in A and B but in the same order.

**Mission 3.** The prefix function pi[i] is the length of the longest border (a beginning that is also an ending) of the first i+1 letters of the marker. When a mismatch comes after k matched letters, the last k letters of the text are equal to the first k letters of the marker, so the next possible match can only start from the longest border pi[k-1]. KMP continues from there and does not look at the text letters again: only the number k goes down, the pointer in the text only goes forward, so the search takes O(n + m). The Border length of my marker AATCAAAT is 3, because AAT is both its beginning and its ending. It means that two hits can overlap by up to 3 letters (the next hit can start 5 letters after the previous one), so after a full match I do not start from 0 but from pi[m-1].

**Mission 4.** Equal hashes do not prove equal words: there are more different words than hash values, so two different words can get the same hash (a collision). Without the letter comparison I could count a window that is not in B. If many windows have the same hash (for example with a very small modulus), every window has to be compared with many candidates letter by letter, and the time goes from O(n + m) towards the slow brute force.

**Mission 5.** For every person v there are two numbers. in[v] is the cheapest cost of v and everything below him when v is tested: in[v] = cost[v] + the sum over the children c of min(in[c], out[c]) (every child is free to be tested or not). out[v] is the cheapest cost when v is not tested: out[v] = the sum of in[c] over the children, because the link between v and a child must be covered, so every child must be tested. The answer is min(in[0], out[0]) at the root; to find who is tested I go down from the root with the same rule. A greedy "test the person with the most links first" does not always work because it ignores the costs: in a star with a centre that costs 100 and three leaves that cost 1 each, the greedy tests the centre for 100, but testing the three leaves costs only 3.

## AI use

Tool: Claude (Anthropic). I used Claude as an AI assistant while working on this assignment. It helped explain the algorithms, discuss implementation ideas, identify and fix issues, and contribute to parts of the code and README. However, the work was not produced entirely by AI: I completed approximately half of the implementation and written work myself, and I reviewed and tested the resulting program using `tools/Check.java` and my own data. All 9 output lines have a tick in the lab console. The timing numbers below were measured by Claude with `java -cp out Bench` in a Linux environment, not on my own computer. I did not take code from books or websites.

## Timing (Mission 7)

Milliseconds, average of 3 runs, from `java -cp out Bench`.

| test | size | time |
|---|---|---|
| naive search | 20 000 | 53.0 |
| naive search | 40 000 | 88.8 |
| naive search | 80 000 | 180.7 |
| KMP | 20 000 | 3.3 |
| KMP | 40 000 | 3.4 |
| KMP | 80 000 | 0.5 |
| edit distance | 500 | 10.8 |
| edit distance | 1000 | 10.8 |
| edit distance | 2000 | 21.3 |
| edit distance | 4000 | 119.2 |

When the text doubles, the naive search takes about twice as long (53, 89, 181 ms), as expected for O(n * m) with a fixed pattern, while KMP stays at a few milliseconds and does not grow with the text (the times of KMP are so small that the JIT warm-up and noise decide them). The edit distance table has n * m cells, so doubling both strains makes it about 4 times slower: 21 ms for 2000 and 119 ms for 4000 (the small sizes are faster than expected because of the JVM warm-up).

## Complexity

n is the length of the text (or of a strain), m the length of the pattern, k the length of the window, v the number of people.

| algorithm | time | space | assumptions |
|---|---|---|---|
| Edit distance | O(n * m) | O(n * m) | one cell per pair of prefixes, each cell is O(1); two rows would be enough for the number only |
| LCS | O(n * m) | O(n * m) | the same table with another rule |
| Prefix function and KMP | O(m) for the prefix function, O(n + m) for the search | O(m) for pi (my findAll also keeps a list of hits, up to O(n)) | the text pointer never goes back; k only falls back as often as it grew |
| Rabin-Karp (shared words) | O(n + m) expected | O(m) for the windows of B | the rolling hash gives each window in O(1); many equal hashes slow it down towards O(n * k) |
| Tree DP | O(v) | O(v) | every person is visited a constant number of times (BFS order, children before parents) |
