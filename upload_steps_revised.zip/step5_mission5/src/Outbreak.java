import java.util.*;

/**
 * Mission 5. Dynamic programming on the tree of infections, rooted in person 0.
 */
public class Outbreak {

    /** BFS order from person 0 and the parent of every person (-1 for the root). */
    private static int[] bfsOrder(int n, int[][] nb, int[] parent) {
        int[] order = new int[n];
        boolean[] seen = new boolean[n];
        int head = 0, tail = 0;
        Arrays.fill(parent, -1);
        order[tail++] = 0;
        seen[0] = true;
        while (head < tail) {
            int v = order[head++];
            for (int u : nb[v]) {
                if (!seen[u]) { seen[u] = true; parent[u] = v; order[tail++] = u; }
            }
        }
        return Arrays.copyOf(order, tail);
    }

    /**
     * in[v]  = cheapest cost of the subtree of v when v IS tested (children are free to choose);
     * out[v] = cheapest cost when v is NOT tested (every child must be tested).
     */
    public static boolean[] cheapestTests(int n, int[][] nb, int[] cost) {
        boolean[] tested = new boolean[n];
        if (n == 0) return tested;
        int[] parent = new int[n];
        int[] order = bfsOrder(n, nb, parent);
        long[] in = new long[n], out = new long[n];
        for (int i = order.length - 1; i >= 0; i--) {      // leaves first
            int v = order[i];
            in[v] += cost[v];
            if (parent[v] >= 0) {
                int p = parent[v];
                in[p] += Math.min(in[v], out[v]);          // parent tested: child takes the cheaper way
                out[p] += in[v];                           // parent not tested: child must be tested
            }
        }
        // rebuild who is tested, from the root down
        for (int v : order) {
            if (parent[v] < 0) tested[v] = in[v] <= out[v];
            else if (!tested[parent[v]]) tested[v] = true;          // parent not tested: forced
            else tested[v] = in[v] <= out[v];
        }
        return tested;
    }

    /** Longest path in the tree, counted in links: for every person add his two longest ways down. */
    public static int longestChain(int n, int[][] nb) {
        if (n == 0) return 0;
        int[] parent = new int[n];
        int[] order = bfsOrder(n, nb, parent);
        int[] best1 = new int[n], best2 = new int[n];      // two longest ways down from v (in links)
        int chain = 0;
        for (int i = order.length - 1; i >= 0; i--) {
            int v = order[i];
            chain = Math.max(chain, best1[v] + best2[v]);
            if (parent[v] >= 0) {
                int p = parent[v], way = best1[v] + 1;
                if (way > best1[p]) { best2[p] = best1[p]; best1[p] = way; }
                else if (way > best2[p]) best2[p] = way;
            }
        }
        return chain;
    }
}
