/**
 * Missions 1 and 2. Compare two strains with dynamic programming.
 */
public class Strains {

    /**
     * Mission 1. Edit distance. d[i][j] = the smallest number of changes that turn the first i letters of a
     * into the first j letters of b.
     */
    public static int editDistance(String a, String b) {
        int n = a.length(), m = b.length();
        int[][] d = new int[n + 1][m + 1];
        for (int i = 0; i <= n; i++) d[i][0] = i;          // delete i letters to get the empty word
        for (int j = 0; j <= m; j++) d[0][j] = j;          // insert j letters into the empty word
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                if (a.charAt(i - 1) == b.charAt(j - 1)) {
                    d[i][j] = d[i - 1][j - 1];             // last letters equal: nothing to pay
                } else {
                    d[i][j] = 1 + Math.min(d[i - 1][j - 1],            // replace
                                  Math.min(d[i - 1][j],                // delete from a
                                           d[i][j - 1]));              // insert into a
                }
            }
        }
        return d[n][m];
    }

    /**
     * Mission 2. Longest common subsequence. d[i][j] = the LCS length of the first i letters of a and the first j of b.
     */
    public static int lcsLength(String a, String b) {
        int n = a.length(), m = b.length();
        int[][] d = new int[n + 1][m + 1];                 // first row and column stay 0: an empty word has nothing in common
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                if (a.charAt(i - 1) == b.charAt(j - 1)) {
                    d[i][j] = d[i - 1][j - 1] + 1;         // equal letters extend the common subsequence
                } else {
                    d[i][j] = Math.max(d[i - 1][j], d[i][j - 1]);   // otherwise the better of top and left
                }
            }
        }
        return d[n][m];
    }
}
